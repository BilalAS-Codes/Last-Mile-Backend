# Last Mile Logistics Backend Graph

## Modules
- **Auth**: User registration, login, and profile management. Uses JWT.
- **Users**: Admin management of users and drivers.
- **Orders**: Core logistics logic. Creation, assignment, and status tracking.
- **Wallet**: Settlement tracking for drivers (COD collection).
- **Billing**: Invoice generation for clients.

## Data Models (PostgreSQL)
- **users**: {id, name, email, role, password, active, company_details, vehicle_number}
- **orders**: {id, tracking_id, client_id, driver_id, status, order_value, cod_amount, delivery_fee, pickup_address, delivery_address, timeline}
- **settlements**: {id, driver_id, amount, status, admin_id}
- **invoices**: {id, client_id, total_amount, outstanding_balance, status, billing_period, orders}

## Technology Stack
- Node.js (v25+)
- Express.js
- PostgreSQL (pg pool)
- Knex.js (Migrations & Seeds)
- Swagger (API Documentation)
- Joi (Validation)

## Core Endpoints
- `/api/auth`: [POST] /register, /login, [GET] /me
- `/api/orders`: [POST] /, [GET] /, [PATCH] /:id/status, /:id/assign
- `/api/users`: [GET] /, /drivers/active
- `/api/wallet`: [GET] /unsettled, [POST] /settlement
- `/api-docs`: Swagger UI
