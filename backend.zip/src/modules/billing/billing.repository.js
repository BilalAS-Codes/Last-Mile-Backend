const db = require('../../config/db');

class BillingRepository {
    async createInvoice(invoiceData) {
        const { client_id, total_amount, billing_period } = invoiceData;
        const query = `
            INSERT INTO invoices (client_id, total_amount, billing_period, status)
            VALUES ($1, $2, $3, 'UNPAID')
            RETURNING *
        `;
        const result = await db.query(query, [client_id, total_amount, billing_period]);
        return result.rows[0];
    }

    async getInvoicesByClient(clientId) {
        const query = 'SELECT * FROM invoices WHERE client_id = $1 ORDER BY created_at DESC';
        const result = await db.query(query, [clientId]);
        return result.rows;
    }

    async getAllInvoices() {
        const query = 'SELECT * FROM invoices ORDER BY created_at DESC';
        const result = await db.query(query);
        return result.rows;
    }
}

module.exports = new BillingRepository();
